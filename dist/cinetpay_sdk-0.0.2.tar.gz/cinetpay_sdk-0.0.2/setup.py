from setuptools import setup, find_packages  
setup(name = 'cinetpay_sdk', packages = find_packages())