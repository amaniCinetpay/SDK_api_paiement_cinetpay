from setuptools import setup, find_packages  
setup(name = 's_d_k', packages = find_packages())